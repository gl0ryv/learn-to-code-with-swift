//: Swift 5.1

import UIKit

for index in 1...5 {
    print("\(index) times 5 is \(index * 5)")
}
